import dotenv from 'dotenv'
dotenv.config()
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import { checkDatabase } from './db.js'
import authRoutes from './routes/auth.routes.js'
import eventRoutes from './routes/events.routes.js'
import registrationRoutes from './routes/registrations.routes.js'
import adminRoutes from './routes/admin.routes.js'

const app = express()
const port = Number(process.env.PORT || 5000)

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('JWT_SECRET must be set in .env and contain at least 32 characters.')
  process.exit(1)
}

app.disable('x-powered-by')
app.use(helmet())
app.use(cors({
  origin: (process.env.CLIENT_ORIGIN || 'http://localhost:5173').split(',').map(v => v.trim()),
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}))
app.use(express.json({ limit: '1mb' }))
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }))

app.get('/', (_req, res) => res.json({ message: 'College Event Management API is running.' }))
app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'college-event-backend' }))
app.use('/api/auth', authRoutes)
app.use('/api/events', eventRoutes)
app.use('/api/registrations', registrationRoutes)
app.use('/api/admin', adminRoutes)

app.use((req, res) => res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` }))
app.use((err, _req, res, _next) => {
  console.error(err)
  if (res.headersSent) return
  res.status(500).json({
    message: process.env.NODE_ENV === 'production' ? 'Internal server error.' : 'Internal server error. Check the backend terminal for details.'
  })
})

try {
  await checkDatabase()
  app.listen(port, () => console.log(`API server running at http://localhost:${port}`))
} catch (error) {
  console.error('Could not connect to MySQL. Check that MySQL is running and .env credentials are correct.')
  console.error(error.message)
  process.exit(1)
}
