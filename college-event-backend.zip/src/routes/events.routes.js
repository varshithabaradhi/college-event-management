import { Router } from 'express'
import { pool } from '../db.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { requireAuth, requireRole } from '../middleware/auth.js'

const router = Router()
const fields = ['title', 'category', 'date', 'time', 'venue', 'description', 'image', 'tag']
const clean = value => typeof value === 'string' ? value.trim() : ''

function validateEvent(body, partial = false) {
  const result = {}
  const mapping = { title: 'title', category: 'category', date: 'event_date', time: 'event_time', venue: 'venue', description: 'description', image: 'image_url', tag: 'tag' }
  for (const field of fields) {
    if (partial && body[field] === undefined) continue
    const value = clean(body[field])
    if (['title', 'category', 'date', 'venue', 'description'].includes(field) && !value) {
      return { error: `${field} is required.` }
    }
    if (field === 'date' && value && !/^\d{4}-\d{2}-\d{2}$/.test(value)) return { error: 'Date must use YYYY-MM-DD format.' }
    if (field === 'image' && value && (!/^https?:\/\/\S+$/i.test(value) || value.length > 1000)) return { error: 'Image must be a valid HTTP or HTTPS URL (up to 1000 characters).' }
    const max = { title: 180, category: 60, time: 40, venue: 180, description: 10000, image: 1000, tag: 60 }
    if (max[field] && value.length > max[field]) return { error: `${field} is too long.` }
    result[mapping[field]] = value || null
  }
  if (result.event_time === null && !partial) result.event_time = '10:00 AM'
  return { value: result }
}

const SELECT_EVENTS = `
  SELECT e.id, e.title, e.category, DATE_FORMAT(e.event_date, '%Y-%m-%d') AS date,
         e.event_time AS time, e.venue, e.description, e.image_url AS image,
         e.tag, COUNT(r.id) AS registrations, e.created_at AS createdAt
  FROM events e LEFT JOIN registrations r ON r.event_id = e.id
`

router.get('/', asyncHandler(async (req, res) => {
  const search = String(req.query.search || '').trim().slice(0, 120)
  const category = String(req.query.category || '').trim().slice(0, 60)
  const params = []
  let where = ''
  if (search) {
    where += ' WHERE (e.title LIKE ? OR e.description LIKE ? OR e.venue LIKE ?)'
    params.push(`%${search}%`, `%${search}%`, `%${search}%`)
  }
  if (category && category !== 'All events') {
    where += where ? ' AND e.category = ?' : ' WHERE e.category = ?'
    params.push(category)
  }
  const [rows] = await pool.execute(
    `${SELECT_EVENTS}${where} GROUP BY e.id ORDER BY e.event_date ASC, e.id DESC`,
    params
  )
  res.json({ events: rows })
}))

router.get('/:id', asyncHandler(async (req, res) => {
  const [rows] = await pool.execute(`${SELECT_EVENTS} WHERE e.id = ? GROUP BY e.id`, [req.params.id])
  if (!rows[0]) return res.status(404).json({ message: 'Event not found.' })
  res.json({ event: rows[0] })
}))

router.post('/', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const parsed = validateEvent(req.body)
  if (parsed.error) return res.status(400).json({ message: parsed.error })
  const e = parsed.value
  const [result] = await pool.execute(
    `INSERT INTO events (title, category, event_date, event_time, venue, description, image_url, tag, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [e.title, e.category, e.event_date, e.event_time, e.venue, e.description, e.image_url, e.tag, req.user.id]
  )
  const [rows] = await pool.execute(`${SELECT_EVENTS} WHERE e.id = ? GROUP BY e.id`, [result.insertId])
  res.status(201).json({ message: 'Event created.', event: rows[0] })
}))

router.put('/:id', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const parsed = validateEvent(req.body, true)
  if (parsed.error) return res.status(400).json({ message: parsed.error })
  const entries = Object.entries(parsed.value)
  if (!entries.length) return res.status(400).json({ message: 'Provide at least one event field to update.' })
  const [exists] = await pool.execute('SELECT id FROM events WHERE id = ?', [req.params.id])
  if (!exists.length) return res.status(404).json({ message: 'Event not found.' })
  const setClause = entries.map(([key]) => `${key} = ?`).join(', ')
  await pool.execute(`UPDATE events SET ${setClause} WHERE id = ?`, [...entries.map(([, value]) => value), req.params.id])
  const [rows] = await pool.execute(`${SELECT_EVENTS} WHERE e.id = ? GROUP BY e.id`, [req.params.id])
  res.json({ message: 'Event updated.', event: rows[0] })
}))

router.delete('/:id', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const [result] = await pool.execute('DELETE FROM events WHERE id = ?', [req.params.id])
  if (!result.affectedRows) return res.status(404).json({ message: 'Event not found.' })
  res.json({ message: 'Event deleted.' })
}))

export default router
