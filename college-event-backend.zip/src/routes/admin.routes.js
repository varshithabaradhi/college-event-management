import { Router } from 'express'
import { pool } from '../db.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { requireAuth, requireRole } from '../middleware/auth.js'

const router = Router()
router.use(requireAuth, requireRole('admin'))

router.get('/summary', asyncHandler(async (_req, res) => {
  const [[eventRow]] = await pool.execute('SELECT COUNT(*) AS totalEvents FROM events')
  const [[studentRow]] = await pool.execute("SELECT COUNT(*) AS totalStudents FROM users WHERE role = 'student'")
  const [[registrationRow]] = await pool.execute('SELECT COUNT(*) AS totalRegistrations FROM registrations')
  res.json({
    totalEvents: Number(eventRow.totalEvents),
    totalStudents: Number(studentRow.totalStudents),
    totalRegistrations: Number(registrationRow.totalRegistrations)
  })
}))

export default router
