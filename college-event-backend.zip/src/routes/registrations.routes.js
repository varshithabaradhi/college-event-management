import { Router } from 'express'
import { pool } from '../db.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { requireAuth, requireRole } from '../middleware/auth.js'

const router = Router()

router.get('/mine', requireAuth, requireRole('student'), asyncHandler(async (req, res) => {
  const [rows] = await pool.execute(
    `SELECT e.id, e.title, e.category, DATE_FORMAT(e.event_date, '%Y-%m-%d') AS date,
            e.event_time AS time, e.venue, e.description, e.image_url AS image, e.tag,
            r.registered_at AS registeredAt
     FROM registrations r JOIN events e ON e.id = r.event_id
     WHERE r.user_id = ? ORDER BY e.event_date ASC`,
    [req.user.id]
  )
  res.json({ registrations: rows })
}))

router.post('/:eventId', requireAuth, requireRole('student'), asyncHandler(async (req, res) => {
  const [events] = await pool.execute('SELECT id, event_date FROM events WHERE id = ?', [req.params.eventId])
  if (!events.length) return res.status(404).json({ message: 'Event not found.' })
  try {
    await pool.execute('INSERT INTO registrations (user_id, event_id) VALUES (?, ?)', [req.user.id, req.params.eventId])
    res.status(201).json({ message: 'You are registered for this event.' })
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ message: 'You are already registered for this event.' })
    throw error
  }
}))

router.delete('/:eventId', requireAuth, requireRole('student'), asyncHandler(async (req, res) => {
  const [result] = await pool.execute(
    'DELETE FROM registrations WHERE user_id = ? AND event_id = ?',
    [req.user.id, req.params.eventId]
  )
  if (!result.affectedRows) return res.status(404).json({ message: 'Registration not found.' })
  res.json({ message: 'Registration cancelled.' })
}))

router.get('/event/:eventId', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const [rows] = await pool.execute(
    `SELECT r.id, r.registered_at AS registeredAt, u.id AS studentId, u.name, u.email
     FROM registrations r JOIN users u ON u.id = r.user_id
     WHERE r.event_id = ? ORDER BY r.registered_at DESC`,
    [req.params.eventId]
  )
  res.json({ registrations: rows })
}))

export default router
