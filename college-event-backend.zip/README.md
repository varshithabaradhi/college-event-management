# Online College Event Management System — Backend

Backend API: Node.js + Express + MySQL.

## Requirements
- Node.js LTS and npm
- MySQL Server (and MySQL Workbench optional)
- Your React frontend running at `http://localhost:5173`

## 1. Create database
Open MySQL Workbench or MySQL command line and execute all of `database.sql`.

## 2. Configure environment
Copy `.env.example` to a new file named `.env`.
Set your MySQL password and create a long random `JWT_SECRET` (at least 32 characters).
Do not commit `.env` to GitHub.

Example:
```env
PORT=5000
NODE_ENV=development
CLIENT_ORIGIN=http://localhost:5173
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_actual_mysql_password
DB_NAME=college_event_db
JWT_SECRET=use_a_long_random_secret_at_least_32_characters
JWT_EXPIRES_IN=1d
```

## 3. Install and start
Open this backend folder in VS Code terminal:
```bash
npm install
npm run dev
```
Expected terminal messages:
- `MySQL connected successfully`
- `API server running at http://localhost:5000`

Test `http://localhost:5000/api/health` in a browser.

## 4. Create an admin
Public registration always creates a student. To promote your own account, register a user through `/api/auth/register`, then run this SQL in MySQL Workbench, substituting the email you registered:
```sql
UPDATE users SET role = 'admin' WHERE email = 'your-admin-email@college.edu';
```
Log out and log in again to receive a token with the admin role. Never expose a public admin-registration route.

## API endpoints
All request/response bodies are JSON. For protected endpoints send:
`Authorization: Bearer YOUR_JWT_TOKEN`

### Auth
- `POST /api/auth/register` body `{ "name": "Student Name", "email": "student@example.com", "password": "password123" }`
- `POST /api/auth/login` body `{ "email": "student@example.com", "password": "password123" }`
- `GET /api/auth/me` protected

### Events
- `GET /api/events`
- `GET /api/events?search=code&category=Technology`
- `GET /api/events/:id`
- `POST /api/events` admin only; body example:
```json
{
  "title": "College Tech Fest",
  "category": "Technology",
  "date": "2026-11-15",
  "time": "10:00 AM",
  "venue": "Main Auditorium",
  "description": "A day of coding, talks and competitions.",
  "image": "https://example.com/event.jpg",
  "tag": "Featured"
}
```
- `PUT /api/events/:id` admin only; send fields to update
- `DELETE /api/events/:id` admin only

### Registrations
- `GET /api/registrations/mine` student only
- `POST /api/registrations/:eventId` student only
- `DELETE /api/registrations/:eventId` student only
- `GET /api/registrations/event/:eventId` admin only

### Admin
- `GET /api/admin/summary` admin only

## Frontend integration
The supplied React demo uses localStorage for demo sessions, events and registrations. It will NOT automatically call this backend. Update the frontend to:
1. Set `VITE_API_URL=http://localhost:5000` in the frontend `.env` file.
2. Use `fetch(`${import.meta.env.VITE_API_URL}/api/auth/login`, ...)` for login.
3. Store the returned token in memory or a carefully considered session strategy and send it in `Authorization: Bearer <token>` on protected calls.
4. Load events from `GET /api/events`.
5. Call registration and admin event endpoints for their respective actions.
For production, prefer secure HttpOnly cookies if your architecture supports them; do not store sensitive secrets in frontend code.

## Deploy backend on Render
- Push backend to a GitHub repository.
- Create a Render Web Service from that repository.
- Build command: `npm install`
- Start command: `npm start`
- Add all `.env` variables in Render Environment settings. Set `CLIENT_ORIGIN` to your deployed Vercel frontend URL.
- Set `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, and `DB_NAME` to an accessible MySQL provider. Render web service storage is not a replacement for a MySQL database.
- Test `/api/health`.
