CREATE DATABASE IF NOT EXISTS college_event_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE college_event_db;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('student', 'admin') NOT NULL DEFAULT 'student',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  category VARCHAR(60) NOT NULL,
  event_date DATE NOT NULL,
  event_time VARCHAR(40) NOT NULL DEFAULT '10:00 AM',
  venue VARCHAR(180) NOT NULL,
  description TEXT NOT NULL,
  image_url VARCHAR(1000) NULL,
  tag VARCHAR(60) NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_events_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_events_date (event_date),
  INDEX idx_events_category (category)
);

CREATE TABLE IF NOT EXISTS registrations (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  event_id BIGINT UNSIGNED NOT NULL,
  registered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_user_event UNIQUE (user_id, event_id),
  CONSTRAINT fk_reg_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_reg_event FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  INDEX idx_reg_event (event_id)
);

-- Optional sample events. They are safe to remove if you want an empty database.
INSERT INTO events (title, category, event_date, event_time, venue, description, image_url, tag)
SELECT 'Ignite 2026: Annual Fest', 'Fest', '2026-10-24', '10:00 AM', 'Main Campus Grounds',
       'A full day of music, dance, games, food stalls and campus memories.',
       'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?auto=format&fit=crop&w=1200&q=85', 'Featured'
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title = 'Ignite 2026: Annual Fest');

INSERT INTO events (title, category, event_date, event_time, venue, description, image_url, tag)
SELECT 'CodeSprint Hackathon', 'Technology', '2026-10-28', '9:00 AM', 'Innovation Lab',
       'Build useful ideas with your team in a fast-paced coding challenge.',
       'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=85', 'Popular'
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title = 'CodeSprint Hackathon');
